Cookie Clicker
==============

A clone of the original game here: http://orteil.dashnet.org/cookieclicker/

For "educational" purposes.
